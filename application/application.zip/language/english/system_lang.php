<?php

#Version 3.0.1

$lang['project_name'] = 'Fund Management';
$lang['project_short_name'] = 'Fund Management';

?>