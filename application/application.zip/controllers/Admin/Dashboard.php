<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
    public function __construct() {
        parent::__construct();
        if(empty($this->session->userdata('username'))){
            redirect(base_url());
        }
    }
    
    public function index() {
        $main_menu['active'] = 'Dashboard';
        $this->session->set_userdata($main_menu);
        
        $data['topbar'] = "Dashboard";
        
        $this->load->view('layout/Admin/header', $data);
        $this->load->view('layout/Admin/sidebar', $data);
        $this->load->view('Admin/index', $data);
        $this->load->view('layout/Admin/footer', $data);
    }

}
